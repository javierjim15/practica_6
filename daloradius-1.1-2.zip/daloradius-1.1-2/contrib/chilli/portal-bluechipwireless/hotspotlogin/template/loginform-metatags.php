<?php

echo '

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>bluechip wireless - WiFi internet service in Koh Samui</title>
<meta name="description" content="bluechip wireless - fast broadband wifi internet service in Koh Samui, Thailand" />
<meta name="keywords" content="wifi samui, samui wifi, internet samui, samui internet, broadband wifi wireless, koh samui Thailand, samui wifi support, samui internet locations, samui wifi cards, samui internet service" />
<link href="template/portal_styles.css" rel="stylesheet" type="text/css" media="screen"/>
<link rel="shortcut icon" href="http://www.bluechipwireless.com/favicon.ico" />


	';
	
?>
